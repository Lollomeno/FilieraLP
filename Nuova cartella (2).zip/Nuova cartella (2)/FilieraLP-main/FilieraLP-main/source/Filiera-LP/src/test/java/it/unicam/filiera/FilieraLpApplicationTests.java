package it.unicam.filiera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilieraLpApplicationTests {

	@Test
	void contextLoads() {
	}

}
