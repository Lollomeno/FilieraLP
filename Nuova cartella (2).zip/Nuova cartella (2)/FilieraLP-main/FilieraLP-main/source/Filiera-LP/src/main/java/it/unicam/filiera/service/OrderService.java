
package it.unicam.filiera.service;

import it.unicam.filiera.model.entity.Ordine;
import it.unicam.filiera.service.payment.PaymentResult;
import it.unicam.filiera.service.payment.PaymentStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.Optional;

@Service
public class OrderService {

    // Spring inietterà qui una Mappa di tutte le implementazioni di PaymentStrategy,
    // usando il nome del bean ("creditcard", "paypal") come chiave.
    private final Map<String, PaymentStrategy> paymentStrategies;

    @Autowired
    public OrderService(Map<String, PaymentStrategy> paymentStrategies) {
        this.paymentStrategies = paymentStrategies;
    }
    
    public void processaPagamentoOrdine(Ordine ordine, String paymentMethod) {
        // 1. Seleziona la strategia corretta in base al nome
        PaymentStrategy strategy = Optional.ofNullable(paymentStrategies.get(paymentMethod))
            .orElseThrow(() -> new IllegalArgumentException("Metodo di pagamento non valido: " + paymentMethod));

        // 2. Esegui il pagamento usando la strategia selezionata
        PaymentResult result = strategy.pay(ordine.getTotale());

        // 3. Aggiorna lo stato dell'ordine in base al risultato
        if ("SUCCESS".equals(result.getStatus())) {
            // ordine.setStato(StatoOrdine.PAGATO);
            // ordine.setDatiPagamento(result.getTransactionId());
            // orderRepository.save(ordine);
            System.out.println("Ordine " + ordine.getId() + " pagato con successo. Transaction ID: " + result.getTransactionId());
        } else {
            // Gestisci il pagamento fallito...
            System.out.println("Pagamento per l'ordine " + ordine.getId() + " fallito.");
        }
    }
    
    // ... altro codice dell'OrderService ...
}