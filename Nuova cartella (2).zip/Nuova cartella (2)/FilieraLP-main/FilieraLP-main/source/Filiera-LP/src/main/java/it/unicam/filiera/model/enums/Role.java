
package it.unicam.filiera.model.enums;

public enum Role {
    PRODUTTORE,
    TRASFORMATORE,
    DISTRIBUTORE,
    CURATORE,
    ANIMATORE,
    ACQUIRENTE,
    GESTORE_PIATTAFORMA
}