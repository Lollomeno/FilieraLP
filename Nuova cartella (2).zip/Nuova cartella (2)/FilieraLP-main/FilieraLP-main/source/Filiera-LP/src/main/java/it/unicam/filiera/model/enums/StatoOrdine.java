
package it.unicam.filiera.model.enums;

public enum StatoOrdine {
    IN_CREAZIONE,
    PAGATO,
    IN_PREPARAZIONE,
    SPEDITO,
    CONSEGNATO,
    ANNULLATO
}