
package it.unicam.filiera.model.enums;

public enum Pubblicazione {
    DRAFT,
    IN_REVISIONE,
    PUBBLICATO,
    RIFIUTATO,
    SCADUTO
}