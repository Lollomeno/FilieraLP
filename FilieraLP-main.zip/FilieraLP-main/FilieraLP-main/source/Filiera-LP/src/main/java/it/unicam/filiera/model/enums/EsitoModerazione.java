
package it.unicam.filiera.model.enums;

public enum EsitoModerazione {
    APPROVATO,
    RIFIUTATO
}